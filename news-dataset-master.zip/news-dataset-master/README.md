# news-dataset

A CSV dataset with more than 40k rows between entire news articles and news headings in English.

## Structure

The dataset is made up of two columns: _news_ and _category_.

The category column can have one of these values:

  - business
  - entertainment
  - politics
  - sport
  - tech
  - world
  - health
  - us
